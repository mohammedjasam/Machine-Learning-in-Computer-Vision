Steps:
1. Run the code.m
2. Change colorspaces if needed
3. For multiple k, uncomment the for loop
4. Enable Plot variable to 1 to display the values for different K