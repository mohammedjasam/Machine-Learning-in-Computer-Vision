Instructions to run the code:
1. "main.m" is the driver file, run it to execute the hw6
2. Change the colorSpace to check the result in different colorspaces
3. change the K value to get the result for that particular K
4. "display_images" is a flag to display the test image and its match
5. "var_k" is a flag to enable the multiple k run, you can expect the Accuracy Matrix of K vs Euclidean, K vs Manhattan, K vs Mahalanobis
6. If you execute var_k you will also have 3 graphs displaying K vs similarity measure.