Instructions:
1. Run code.m
2. Change 'Threshold' to increase or decrease the number of dimensions during feature selection.