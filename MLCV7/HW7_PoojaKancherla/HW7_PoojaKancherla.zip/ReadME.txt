All 5 tasks are in separate files

To execute the files follow these steps:
1. Run Linear_Regression.m for Linear Regression
2. Run Feature_Selection.m for Linear Regression with Feature Selection
3. Run Bayesian_Regularization.m for Bayesian Solution for the selected features
4. Run Non_linear_Regression.m for Non Linear Regression using Feature Selection
5. Run Dual_Non_Linear_Regression.m for Dual Non - LR without Feature Selection
6. If you want to run all and visualize all then run 'Visualize_All.m'.