Steps:
1. Each method is individually placed in its file starting with A***
2. You can just run to obtain the outputs
3. To generate more figures change the value of 'num_of_op' but limit it to a small number as it can get clumsy
4. Report is present in the same folder
5. You can change different parameters like lambda, nu to get variable output
6. To run experiment 6 with on variable iterations change the num_iterations and uncomment the for loop